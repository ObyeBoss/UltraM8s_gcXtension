### 08.09.2023
* MMTEX update
* Support for KSU & canary Magisk
* Updated blobs
* Added ubwc disabler prop